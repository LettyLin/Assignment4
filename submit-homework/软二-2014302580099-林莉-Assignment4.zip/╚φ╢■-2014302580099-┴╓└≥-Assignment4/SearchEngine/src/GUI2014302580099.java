import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;

/**
 * Created by LinLi on 2015/11/11.
 */
public class GUI2014302580099 extends JFrame{
    public String text;
    SearchEngine2014302580099 searchEngine2014302580099;
    public GUI2014302580099()
    {
        searchEngine2014302580099 = new SearchEngine2014302580099();
        createGUI();
        setSize(500,400);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
    public void createGUI()
    {
        Container c = getContentPane();

        JPanel jPanel1 = new JPanel();
        JPanel jPanel2 = new JPanel();

        JTextField jTextField = new JTextField(" ");
        jTextField.setColumns(15);
        JButton jButton = new JButton("Search");


        jPanel1.add(jTextField);
        jPanel1.add(jButton);
        jPanel1.setBounds(50,50,400,50);

        JTextArea jTextArea = new JTextArea(10,20);
        jTextArea.setLineWrap(true);//����
        JScrollPane jScrollPane = new JScrollPane(jTextArea);

        jPanel2.setBounds(50,100,400,300);
        jPanel2.add(jScrollPane);

        c.add(jPanel1);
        c.add(jPanel2);

        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                text = jTextField.getText();
                text = text.substring(0,text.length()-1);
                jTextArea.setText(searchEngine2014302580099.Output(text));
            }
        });
    }

}