import java.sql.SQLException;

/**
 * Created by LinLi on 2015/11/14.
 */
public class SearchEngine2014302580099 {
    WriteToTeachers2014302580099 writeToTeachers2014302580099;
    public SearchEngine2014302580099()
    {
        try{
        writeToTeachers2014302580099 = new WriteToTeachers2014302580099();
    }catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    public String Output(String text) {
        writeToTeachers2014302580099.culculateTF(text);
        try{
        writeToTeachers2014302580099.Order();}
        catch (SQLException e){
            e.printStackTrace();
        }
        String output="";
        for (Teacher2014302580099 teacher:writeToTeachers2014302580099.teachersList) {
            if (teacher.get_tf() > 0) {
                output += "Name:" + teacher.get_name() +
                        "\nInformation:" + teacher.get_info() +
                        "\nPhone Number:" + teacher.get_phoneNumber() +
                        "\nE-mail:" + teacher.get_email()+"\n\n";
            }
        }
        return output;
    }
}
