import java.sql.SQLException;

/**
 * Created by LinLi on 2015/11/13.
 */
public class Main2014302580099 {
    public static void main(String[] args)throws SQLException
    {
        GUI2014302580099 gui2014302580099 = new GUI2014302580099();
    }
}
