/**
 * Created by LinLi on 2015/11/14.
 */
public class Teacher2014302580099 {
    private String _name;
    private String _info;
    private String _phoneNumber;
    private String _email;
    private double _tf = 0;
    public void set_name(String name)
    {
        _name = name;
    }

    public void set_phoneNumber(String phoneNumber)
    {
        _phoneNumber = phoneNumber;
    }

    public void set_email(String email)
    {
        _email = email;
    }

    public void set_tf(double tf){_tf = tf;}

    public void set_info(String info){_info = info;}

    public double get_tf(){return _tf;}

    public String get_name()
    {
        return _name;
    }

    public String get_phoneNumber()
    {
        return _phoneNumber;
    }

    public String get_info(){return  _info;}

    public String get_email()
    {
        return _email;
    }
}
