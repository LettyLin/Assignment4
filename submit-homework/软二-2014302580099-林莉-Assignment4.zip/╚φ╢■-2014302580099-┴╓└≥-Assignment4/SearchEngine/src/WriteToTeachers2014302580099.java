import java.sql.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;

/**
 * Created by LinLi on 2015/11/14.
 */
public class WriteToTeachers2014302580099 {
    private Connection con = null;
    private int teachersNumber = 0;
    public Vector<Teacher2014302580099> teachersList = new Vector<>();

    public WriteToTeachers2014302580099() throws SQLException
    {
        init();
        getTeachersInfo();
    }
    public void init()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
        }catch (Exception e)
        {
            System.out.print("Fail to connect mysql!");
            e.printStackTrace();
        }
    }

    public void getTeachersInfo()throws SQLException
    {
        Statement statement = null;
        ResultSet resultSet = null;

        String sql = "SELECT * FROM _professor_info";
        statement = con.createStatement();
        resultSet = statement.executeQuery(sql);
        while(resultSet.next())
        {
            Teacher2014302580099 teacher = new Teacher2014302580099();
            teacher.set_name(resultSet.getString(1));
            teacher.set_info(resultSet.getString(2));
            teacher.set_phoneNumber(resultSet.getString(3));
            teacher.set_email(resultSet.getString(4));
            teachersNumber++;
            teachersList.add(teacher);
        }
    }

    public void culculateTF(String inputText)
    {
        List<String> name = new ArrayList<>();
        List<String> info = new ArrayList<>();

        for(int i=0;i<teachersNumber;i++)
        {
            Teacher2014302580099 teacher = teachersList.get(i);

            double existence = 0;
            double allWords = 0;

            name.clear();
            info.clear();

            for(String temp:teacher.get_name().split(" "))
            {
                name.add(temp);
            }
            for(String temp:teacher.get_info().split(" "))
            {
                info.add(temp);
            }

            for(int j=0;j<name.size();j++)
            {
                String a = name.get(j).toString();
                if(inputText.equals(a))
                {
                    existence++;
                }
            }
            for(int j=0;j<info.size();j++)
            {
                String a = info.get(j).toString();
                if(inputText.equals(a))
                {
                    existence++;
                }
            }
            if(teacher.get_phoneNumber().contains(inputText))
            {
                existence++;
            }
            if(teacher.get_email().contains(inputText))
            {
                existence++;
            }
            allWords = name.size()+info.size()+2*teachersList.size();
            teacher.set_tf(existence/allWords);
        }
    }


    public void Order() throws  SQLException
    {
        teachersList.sort(new Comparator<Teacher2014302580099>() {
            @Override
            public int compare(Teacher2014302580099 o1, Teacher2014302580099 o2) {
                return (o1.get_tf()>o2.get_tf() ? -1 : 1);
            }
        });
    }
}
